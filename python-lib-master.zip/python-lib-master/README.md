# manojextension
## In this extension it preload the Title and Author labels in a notebook.
